# 宏参数 block 来自 config.mcfunction；只在目标不匹配时替换，保留正常挖掘进度。
# replace 不给被占位方块额外掉落；玩家挖掘的原版掉落不受影响。
$execute unless block 0 100 0 $(block) run setblock 0 100 0 $(block) replace
