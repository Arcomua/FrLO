# 停止补回，不删除现有方块。卸载前请先执行本函数。
scoreboard players set #enabled obs_ctl 0
execute if score #owns_chunk obs_ctl matches 1 in minecraft:overworld run forceload remove 0 0
scoreboard players set #owns_chunk obs_ctl 0
tellraw @a {"text":"[单方块] 已停止补回。卸载时可直接移除数据包；执行 /reload 会重新启用。","color":"yellow"}
