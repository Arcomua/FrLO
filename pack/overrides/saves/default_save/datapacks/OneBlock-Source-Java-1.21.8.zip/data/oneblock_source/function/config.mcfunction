# 已填写：Simple Lucky Block 1.0.0（Minecraft 1.21.8 / Fabric）。
# 已核对 Modrinth 版本 K0pNzvHP 的 JAR：命名空间 simple_lucky_block，方块名 lucky_block。
# 运行环境必须安装该模组和 Fabric API；仅安装数据包不会添加这个方块。
# 如需更换方块，只修改下面这一行的 block 字符串，保存后执行 /reload。
data modify storage oneblock_source:config settings set value {block:"simple_lucky_block:lucky_block"}
