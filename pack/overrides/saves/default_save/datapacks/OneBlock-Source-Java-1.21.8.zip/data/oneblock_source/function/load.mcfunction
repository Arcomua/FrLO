# Minecraft Java 1.21.8；同名目标已存在时的提示可以忽略。
scoreboard objectives add obs_ctl dummy
function oneblock_source:config
scoreboard players set #enabled obs_ctl 1
function oneblock_source:internal/force_chunk
function oneblock_source:tick
tellraw @a [{"text":"[单方块] 已启用：主世界 (0,100,0)，方块：","color":"green"},{"nbt":"settings.block","storage":"oneblock_source:config","color":"yellow"}]
