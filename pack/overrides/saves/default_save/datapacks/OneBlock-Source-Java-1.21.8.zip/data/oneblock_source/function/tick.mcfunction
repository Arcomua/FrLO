# 区块首次加载可能不是同步完成，等待其就绪后再放置；随后每刻检查。
execute if score #enabled obs_ctl matches 1 in minecraft:overworld if loaded 0 100 0 run function oneblock_source:internal/ensure with storage oneblock_source:config settings
