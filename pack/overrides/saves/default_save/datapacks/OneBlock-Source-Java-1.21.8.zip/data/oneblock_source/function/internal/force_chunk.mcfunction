# 仅强制加载主世界含 (0,100,0) 的一个区块。
# 如果区块原先已被其他用途强制加载，停用时不取消其加载。
execute in minecraft:overworld store success score #already_forced obs_ctl run forceload query 0 0
execute if score #already_forced obs_ctl matches 0 in minecraft:overworld store success score #owns_chunk obs_ctl run forceload add 0 0
