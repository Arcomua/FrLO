# 单方块生存方块源 · Minecraft Java 1.21.8

目标位置：**主世界 `(0, 100, 0)`**。数据包格式为 `81`，不适用于基岩版。

## 已配置的幸运方块

已按你提供的 Modrinth 版本 `K0pNzvHP` 配置为 **Simple Lucky Block 1.0.0（Minecraft 1.21.8 / Fabric）**，方块 ID 是 **`simple_lucky_block:lucky_block`**。

`data/oneblock_source/function/config.mcfunction` 中已填写：

```mcfunction
data modify storage oneblock_source:config settings set value {block:"simple_lucky_block:lucky_block"}
```

注册名已通过所链接版本 JAR 内的 `com.simpleluckyblock.ModBlocks` 注册代码、`fabric.mod.json` 和 `assets/simple_lucky_block/blockstates/lucky_block.json` 交叉核对，并校验 JAR 的 SHA-512 与 Modrinth 一致。

运行时需要安装该模组及 Fabric API。JAR 声明的环境要求为 Minecraft `~1.21.8`、Fabric Loader `>=0.16.14`、Java `>=21`。联机时服务端和客户端都需要相应模组环境；数据包本身不会添加幸运方块。

今后若要更换方块，只需改这个配置文件。例如橡木原木：

```mcfunction
data modify storage oneblock_source:config settings set value {block:"minecraft:oak_log"}
```

也支持 `minecraft:oak_log[axis=y]` 这样的方块状态。方块 ID 必须已由当前游戏或模组注册，不能写中文显示名称。只需改这个配置文件，不必改其他函数。保存后在游戏中执行 `/reload`。

请选择能独立悬空、可正常挖掘、不会自行变成其他方块的普通方块，例如石头、原木、圆石。不要使用空气、液体、沙子/砂砾等重力方块、火、植物、火把等依赖环境的方块。悬空的重力方块可能持续掉落，无法保证留在原坐标。基岩、屏障等不可在生存模式挖掘的方块也不适合作为资源来源。门、床等多格方块以及容器/其他方块实体不是本包的目标用途；不会复制其内容或多格结构。

## 安装

1. 先在 Minecraft 1.21.8 的 Fabric 环境安装 Simple Lucky Block 1.0.0 及 Fabric API。交付包已填写幸运方块 ID，无需再修改。
2. 把交付 ZIP 直接放进你的世界的 `datapacks` 文件夹；也可以解压后，把包含 `pack.mcmeta` 与 `data` 的文件夹放进去。自行重新打包时，确保 `pack.mcmeta` 和 `data` 位于 ZIP 根目录。
3. 进入世界执行 `/reload`（需要命令权限），并用 `/datapack list enabled` 确认已启用。
4. 在主世界 `(0, 100, 0)` 查看方块。这个位置原有方块会被替换。

可以直接把交付 ZIP 放进 `datapacks`，无需解压。服务器应安装在主世界存档的 `datapacks` 下。若此前已装旧版，请用新版替换旧 ZIP 或文件夹，避免同时保留两份本数据包。

## 行为

- 加载数据包时启动，并强制加载包含目标坐标的**一个区块**，玩家离开时也能持续维护。
- 每游戏刻检查一次。方块被玩家挖掉、被爆炸/生物破坏，或被其他方块占据时，下一次检查会恢复成配置的方块。
- 正常 `20 TPS` 下恢复延迟最多约 `0.05` 秒；服务器卡顿或暂停时会随游戏刻变慢。区块初次加载期间，会等待区块就绪。
- 不对仍然匹配配置的方块重复执行 `setblock`，所以玩家能正常完成挖掘。
- 玩家挖掘的掉落和幸运事件由 Simple Lucky Block 模组处理；本数据包只补回方块，不额外生成奖励。
- 替换占位方块使用 `replace`，不会为普通被替换方块主动生成挖掘掉落；不要在这个坐标放容器或贵重方块。
- 只维护主世界这一处坐标，不生成生存平台、不传送玩家，不修改全局游戏规则。

原版数据包通过事后恢复维持方块源，**无法严格阻止爆炸、活塞等先改变该方块，也不保证“只有玩家能破坏”或零时间空隙**。活塞可能把可移动的方块移到别处，再由本包补回，因此仍可能被用于自动获取方块。这是按你确认的“纯数据包、持续提供方块”方案制作的版本。

## 停用和卸载

先执行：

```mcfunction
/function oneblock_source:stop
```

这会停止补回并解除本包新增的区块强制加载；现有方块不会被删除。接着移除 ZIP/文件夹，再执行 `/reload`。如果数据包还在，`/reload` 会重新启用它。

若你绕过停用函数直接移除了数据包，可以检查 `/execute in minecraft:overworld run forceload query 0 0`，并按需要手动移除。本包会记录区块是否原本已被强制加载，原本已加载的区块不会在停用时解除。若其他系统后来也依赖同一区块，请协调其强制加载设置。

## 自查

安装模组并 `/reload` 后：检查初次生成、挖掘后恢复、用其他方块占位后恢复。若方块没有生成，检查模组及其依赖是否已加载、世界维度、配置 ID、数据包启用状态以及日志中的函数错误。服务器默认出生点保护可能阻止非 OP 玩家挖掘出生点附近；如果此处位于保护范围内，请按服务器玩法调整 `spawn-protection`。

此次幸运方块配置已核对模组 JAR 和交付 ZIP；尚未进行带该模组的游戏内联调。此前原版 1.21.8 服务端的补回逻辑验证使用石头配置。

## 版本依据

- Simple Lucky Block 1.21.8 / Fabric 1.0.0：https://modrinth.com/mod/simple-lucky-block/version/K0pNzvHP
- Mojang 1.21.7（数据包格式 81）：https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-7
- Mojang 1.21.8（热修复版本）：https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-8
- Mojang 1.21（使用单数 function 目录）：https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21
- Mojang 1.20.2（函数宏）：https://feedback.minecraft.net/hc/en-us/articles/19703470383757-Minecraft-Java-Edition-1-20-2
